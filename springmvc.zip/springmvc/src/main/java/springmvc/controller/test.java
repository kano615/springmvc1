package springmvc.controller;

public class test {

}
